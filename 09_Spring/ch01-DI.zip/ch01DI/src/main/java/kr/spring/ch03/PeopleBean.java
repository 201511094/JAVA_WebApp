package kr.spring.ch03;

public class PeopleBean {
	public void eat(String food) {
		System.out.println(food+"를 좋아합니다.");
	}
}