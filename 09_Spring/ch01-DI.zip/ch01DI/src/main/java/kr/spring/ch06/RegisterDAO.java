package kr.spring.ch06;

public class RegisterDAO {
	public void insert() {
		System.out.println("RegisterDAO의 insert() 메소드 실행");
	}
}