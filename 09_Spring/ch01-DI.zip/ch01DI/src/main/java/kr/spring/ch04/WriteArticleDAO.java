package kr.spring.ch04;

public class WriteArticleDAO {
	public void insert() {
		System.out.println("WriteArticleDAO의 insert() 메소드 실행");
	}
}