package kr.spring.ch02;

public class StudentBean {
	public void study(String course) {
		System.out.println(course+"를 공부합니다.");
	}
}