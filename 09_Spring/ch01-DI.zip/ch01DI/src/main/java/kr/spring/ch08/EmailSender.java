package kr.spring.ch08;

public class EmailSender {

	@Override
	public String toString() {
		return "EmailSender 호출";
	}

}