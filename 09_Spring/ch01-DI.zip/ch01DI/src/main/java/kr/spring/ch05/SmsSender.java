package kr.spring.ch05;

public class SmsSender {

	//Source > Generate toString()
	@Override
	public String toString() {
		return "SmsSender 호출";
	}

}