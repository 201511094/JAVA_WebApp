package kr.spring.ch02;

//객체 생성 용도
public class SmsSender {
	
}