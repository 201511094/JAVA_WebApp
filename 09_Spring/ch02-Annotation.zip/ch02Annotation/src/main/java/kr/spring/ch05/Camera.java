package kr.spring.ch05;

import org.springframework.stereotype.Component;

//자동 스캔 대상 지정, 빈 객체로 생성될 예정
@Component
public class Camera {

}