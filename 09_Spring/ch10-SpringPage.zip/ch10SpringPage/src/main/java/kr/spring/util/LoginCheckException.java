package kr.spring.util;

public class LoginCheckException extends Exception{

}