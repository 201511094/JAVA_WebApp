package kr.spring.ch07.service;

/*로그인이 실패하면 예외를 던질 예정, 사용자 정의 예외 클래스*/
public class LoginCheckException extends Exception {

}