package kr.spring.ch05.service;

import kr.spring.ch05.model.SearchCommand;

public class SearchService {
	public String search(SearchCommand command) {
		
		return "검색 완료!";
	}
}