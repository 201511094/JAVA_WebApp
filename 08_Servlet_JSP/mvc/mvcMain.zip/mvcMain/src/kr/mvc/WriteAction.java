package kr.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//request에 데이터 저장
		//데이터가 전송되었다고 가정하고 작성!
		request.setAttribute("message", "새로운 게시물을 등록했습니다.");
		
		return "/views/write.jsp";
	}
	
}