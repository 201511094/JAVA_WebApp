package kr.mvc;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*Servlet클래스*/
//Servlet클래스가 Model클래스를 호출
//Model클래스와 JSP는 일대일 대응, 개수 동일
public class DispatcherServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		requestPro(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		requestPro(request, response);
	}
	
	private void requestPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Action com = null;
		String view = null;
		
		String command = request.getRequestURI();
		System.out.println("command 1 : " + command);	
		//					/mvcMain
		if (command.indexOf(request.getContextPath()) == 0) {
			//맨 앞의 request.getContextPath()값인 /mvcMain 잘라내기
			command = command.substring(request.getContextPath().length());
		}
		System.out.println("command 2 : " + command);
		
		if (command == null || command.equals("/list.do")) {
			com = new ListAction();
		}
		else if (command.equals("/detail.do")) {
			com = new DetailAction();
		}
		else if (command.equals("/write.do")) {
			com = new WriteAction();
		}
		
		//모델 클래스의 메소드 호출
		try {
			view = com.execute(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		//forward방식으로 View(JSP) 호출
		//request를 공유하기 위해 + 주소를 바뀌지 않게 하기 위해 forward방식을 사용
		RequestDispatcher dispatcher = request.getRequestDispatcher(view);
		dispatcher.forward(request, response);
	}
}