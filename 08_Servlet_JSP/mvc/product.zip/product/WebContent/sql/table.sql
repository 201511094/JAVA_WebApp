/*상품정보*/
create table product(
	num number not null primary key,
	id varchar2(12) unique not null,
	passwd varchar2(12) not null,
	name varchar2(30) not null,
	price number(8) not null,
	stock number(9) not null,
	origin varchar2(30) not null,
	reg_date date not null
);

create sequence product_seq;