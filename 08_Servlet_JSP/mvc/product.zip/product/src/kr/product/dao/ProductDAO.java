package kr.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import kr.product.vo.ProductVO;

public class ProductDAO {

	private static ProductDAO instance = new ProductDAO();
	
	public static ProductDAO getInstance() {
		return instance;
	}
	
	private ProductDAO() {}
	
	private Connection getConnection() throws Exception {
		Context initCtx = new InitialContext();
		DataSource ds = (DataSource)initCtx.lookup("java:comp/env/jdbc/xe");
		
		return ds.getConnection();
	}
	
	private void executeClose(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if (rs != null) try {rs.close();} catch(SQLException e) {}
		if (pstmt != null) try {pstmt.close();} catch(SQLException e) {}
		if (conn != null) try {conn.close();} catch(SQLException e) {}
	}
	
	/*회원가입*/
	public void insertProduct(ProductVO product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = getConnection();
			sql = "INSERT INTO PRODUCT(num,id,name,passwd,price,stock,origin,reg_date) VALUES (product_seq.nextval,?,?,?,?,?,?,SYSDATE)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getId());
			pstmt.setString(2, product.getName());
			pstmt.setString(3, product.getPasswd());
			pstmt.setInt(4, product.getPrice());
			pstmt.setInt(5, product.getStock());
			pstmt.setString(6, product.getOrigin());
			pstmt.executeQuery();
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			executeClose(null, pstmt, conn);
		}
	}
	
	public ProductVO getProduct(int num) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		ResultSet rs = null;
		ProductVO product = null;
		
		try {
			conn = getConnection();
			sql = "SELECT * FROM product WHERE num=?";
		
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				product = new ProductVO();
				product.setNum(rs.getInt("num"));
				product.setId(rs.getString("id"));
				product.setPasswd(rs.getString("passwd"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setStock(rs.getInt("stock"));
				product.setOrigin(rs.getString("origin"));
			}
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			executeClose(rs, pstmt, conn);
		}
		
		return product;
	}
	
	/*아이디 중복체크, 로그인 체크*/
	public ProductVO checkProduct(String id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductVO member = null;
		String sql = null;
		
		try {
			//커넥션풀로부터 커넥션을 할당
			conn = getConnection();
			//SQL문 작성
			sql = "SELECT * FROM product WHERE id=?";
			
			//PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql);
			//?에 데이터 바인딩
			pstmt.setString(1, id);
			
			//SQL문을 실행하고 결과행을 ResultSet에 담음
			rs = pstmt.executeQuery();
			if (rs.next()) {
				//자바빈(VO) 객체 생성
				member = new ProductVO();
				member.setId(rs.getString("id"));
				member.setNum(rs.getInt("num"));
				member.setPasswd(rs.getString("passwd"));
			}
		} catch(Exception e) {
			throw new Exception(e);
		} finally {
			executeClose(rs, pstmt, conn);
		}
		
		return member;
	}
	
	/*정보 수정*/
	public void updateProduct(ProductVO product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = getConnection();
			sql = "UPDATE product SET name=?,passwd=?,price=?,stock=?,origin=? WHERE num=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getName());
			pstmt.setString(2, product.getPasswd());
			pstmt.setInt(3, product.getPrice());
			pstmt.setInt(4, product.getStock());
			pstmt.setString(5, product.getOrigin());
			pstmt.setInt(6, product.getNum());

			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			executeClose(null, pstmt, conn);
		}
	}
	
	public void deleteProduct(ProductVO product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = getConnection();
			sql = "DELETE FROM product WHERE num=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, product.getNum());

			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			executeClose(null, pstmt, conn);
		}
	}
	
}